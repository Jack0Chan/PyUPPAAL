# Bug Report Summary

Found a bug while validating the existence property of the system, including

1. Validating the same systems, got different results.

2. M1 models M2, but M2 passes the existence property, while M1 does not.

# Details

## Same systems, diffrent results

`M0_Fail.xml` and `M0_Pass_by_System.xml` only differ in the sequence of the processes in the last line of the `system` element.
   
   - `M0_Pass_by_System.xml` just move `PSPAV` to the beginning of the system.
    
```c
// M0_Fail.xml
system NHRA, PHRASA, NSA, PSAHisA, NHisA, PHisAFP, NFP, PFPAV, PHisASP, NSP, PSPAV, NAV, PAVHisH, NHisH, PHisHHisV, NHisV, PHisVRV, NRV, ConvertIn, ConvertOut, Input, Monitor0, Monitor1, Monitor2, Monitor3, Monitor4, Monitor5, Monitor6,Monitor12, Monitor11;

// M0_Pass_by_System.xml
system PSPAV, NHRA, PHRASA, NSA, PSAHisA, NHisA, PHisAFP, NFP, PFPAV, PHisASP, NSP, NAV, PAVHisH, NHisH, PHisHHisV, NHisV, PHisVRV, NRV, ConvertIn, ConvertOut, Input, Monitor0, Monitor1, Monitor2, Monitor3, Monitor4, Monitor5, Monitor6,Monitor12, Monitor11;
```

## M1 models M2, but M2 passes existence property

`M0_Fail.xml` and `M0_Pass_by_Param.xml` only differ in the `system declarations`, as shown in the following code block.

```c
// M0_Fail.xml
const int tCondMinSPAV = 120;
const int tCondMaxSPAV = 122;

// M0_Pass_by_System.xml
const int tCondMinSPAV = 121;
const int tCondMaxSPAV = 122;
```

![](guard_inv.png)

`tCondMinSPAV` is the guard, while `tCondMaxSPAV` is the invariant. Intuitively smaller guard (`M0_Fail.xml`, 120) shuld be able to pass the existence property if bigger guard (`M0_Pass_by_Param.xml`, 121) passes.